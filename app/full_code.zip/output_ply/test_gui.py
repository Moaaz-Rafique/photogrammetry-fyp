import os
import numpy as np
import open3d as o3d

pcd = o3d.io.read_point_cloud('D:\\fyp\\pdfs\\app\\output_ply\\points2.ply')
pcd.estimate_normals(
    search_param=o3d.geometry.KDTreeSearchParamHybrid(radius=0.1, max_nn=30))
#
pcdN = o3d.geometry.PointCloud()
#
# # pcdN.points=pcd
cwd = os.getcwd()
points = np.concatenate((pcdN.points, pcd.points))
pcdN.points = o3d.utility.Vector3dVector(points)
print(pcdN)

print(f"{cwd}\\output_ply\\points_combined_down.ply")
o3d.io.write_point_cloud(f"{cwd}\\points_combined_down.ply", pcdN)



# self._scene.scene.clear_geometry()
# for i in range(len(pcds)):
# self._scene.scene.add_geometry(f"__model0__", pcd,
#                                self.settings.material)

# try:
#     print("printing sdjh")
#     radii = [0.5, 1, 10]
#     pcd_down = pcd.voxel_down_sample(voxel_size=0.01)
#     pcd_down.estimate_normals()
#     print("printing downsamplws")
#
#     rec_mesh = o3d.geometry.TriangleMesh.create_from_point_cloud_ball_pivoting(
#         pcd_down, o3d.utility.DoubleVector(radii))
#     print('kill myself')
#     o3d.visualization.draw_geometries([rec_mesh])
#     # self._scene.scene.add_geometry(f"__model3__", rec_mesh.translate((-.51, 0, 0)),
#     #                            self.settings.material)
#
# except Exception as e:
#     print(e)
# try:
#     with o3d.utility.VerbosityContextManager(
#             o3d.utility.VerbosityLevel.Debug) as cm:
#         mesh2, densities = o3d.geometry.TriangleMesh.create_from_point_cloud_poisson(
#             pcd, depth=9)
#     o3d.visualization.draw_geometries([mesh2])
# # # print(mesh)
# #
# # # oself._scene.scene.add_geometry(f"__model2__", mesh2.translate((-.51,0,0)),
# # #                            self.settings.material)
# #
# except Exception as e:
#     print(e)
# print("found Model")
